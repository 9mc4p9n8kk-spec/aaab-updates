AAAB (Anti-Anti-Adblocker) — English build

Desktop Chromium / Microsoft Edge:
1. Extract aaab-unpacked.zip.
2. Open edge://extensions (Edge) or chrome://extensions (Chrome).
3. Enable Developer mode.
4. Select Load unpacked and choose the extracted aaab-unpacked folder.

CRX:
- aaab-unpacked.crx is a locally signed CRX3 package. Browser policies may block sideloading it; Load unpacked is the reliable developer-mode route.
- aaab-signing-key.pem is the private key used to sign the CRX. Keep it private and backed up; anyone with it can publish updates under the same extension identity.

Language:
- The extension interface, popup, and settings page are in English.
- Vietnamese locale resources are retained as an optional translation, but English is the default.

Android:
- Standard Microsoft Edge for Android does not support installing desktop CRX or unpacked extensions.

Build note:
- This package was assembled from the supplied source archive using the existing compiled JavaScript and a local TypeScript bundling fallback because npm dependency installation could not complete. UI strings were translated to English. It has not been functionally tested against live websites.
